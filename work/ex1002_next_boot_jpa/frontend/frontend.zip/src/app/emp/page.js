
export default function Emp(){
    return(
        <div>
            <h1>사원목록</h1>
        </div>
    );
};