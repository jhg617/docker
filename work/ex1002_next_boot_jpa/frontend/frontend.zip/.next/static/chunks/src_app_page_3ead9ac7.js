(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_3d8feecb._.js",
  "static/chunks/src_app_page_module_2aa510fc.css"
],
    source: "dynamic"
});
